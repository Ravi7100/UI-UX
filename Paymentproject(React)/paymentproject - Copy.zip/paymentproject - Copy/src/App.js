
import './App.css';
// import {Link} from 'react-router-dom'
import Login from './Components/Login';
import Reset from './Components/Reset';
import Signup from './Components/Signup';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './Components/Home';

function App() {
  return (
    <div className="App">
     <title>DBS</title>
      <Router>
        <Switch>
      <Route exact path="/login" component={Login} /> 
      <Route exact path="/Reset" component={Reset} />
      <Route exact path="/Signup" component={Signup} />
      <Route exact path="/Home" component={Home} /> 
      </Switch>
      </Router>
    </div>
  );
}

export default App;
