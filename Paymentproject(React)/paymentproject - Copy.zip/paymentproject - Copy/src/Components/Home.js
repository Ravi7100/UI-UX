import React from 'react'
import {Link} from 'react-router-dom'
import home from './images/homepage.png'
import logoImg from './images/logo.png'
import logoImg2 from './images/content.jpg'
import './Home.css'
function Home(){
    return(
        <div className = 'mainBg'>   
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"/>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>

            <nav className="navbar navbar-expand-lg navbar-light sticky-top" >
                <p className="navbar-brand" Link to="#"></p>
                <img src={logoImg} width="50px" height="30px" className="d-inline-block align-top" alt="Bank Logo" />
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarText">
                    <ul className="navbar-nav mr-auto"> </ul>
                    <span className="navbar-text">
                        <ul className="navbar-nav mr-auto">
                            <li className= "nav-item active">
                                <p className="nav-link" Link to="#" >Home</p>
                                <span className="sr-only">(current)</span>
                            </li>
                            <li className="nav-item">
                                <p className="nav-link" Link to="#" >Service</p>
                            </li>
                            <li className="nav-item">
                                <p className="nav-link" Link to="#" >Request</p>
                            </li>
                        </ul>
                    </span>
                </div>
            </nav>

            <div className="row m-5 pr-2 d-flex" >
                <div className="col-lg-6">
                    <div className="card1 pb-5">
                        <div className="px-3  mt-4 mb-5 border-line"> <img src={home} width='468px' height='368px'/> </div>
                    </div>
                </div>

                <div className="col-lg-6 ">

                    <form>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                            <label for="inputEmail4">Customer Id</label>
                            <input type="text" className="form-control" id="inputEmail4" placeholder="***********"/>
                            </div>
                            <div className="form-group col-md-6">
                            <label for="inputPassword4">Account Holders Name</label>
                            <input type="text" className="form-control" id="inputPassword4" placeholder="Ravi Teja"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <label for="inputAddress">Bank Name</label>
                            <input type="text" className="form-control" id="inputAddress" placeholder="DBS Bank"/>
                        </div>
                        <div className="form-group">
                            <label for="inputAddress2">Mesage</label>
                            <select id="inputAddress2" className="form-control">
                                <option selected disabled>Choose...</option>
                                <option>CHQB-beneficiary customer must be paid by cheque only</option>
                                <option>CORT-Payment is made in settlement for a trader</option>
                                <option>HOLD-Beneficiary customer or claimant will call upon identification</option>
                                <option>INTC-Payment between two companies that belongs to the same group</option>
                                <option>PHOB-Please advise the intermediary institution by phone</option>
                                <option>PHOI-Please advise the intermediary by phone</option>
                                <option>PHON-Please advise the account with institution by phone</option>
                                <option>REPA-Payments has a related e-Payments reference</option>
                                <option>SDVA-Payment must be executed with same day</option>
                            </select>
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                            <label for="inputCity">BIC CODE</label>
                            <input type="text" className="form-control" id="inputCity" placeholder="************"/>
                            </div>
                            <div className="form-group col-md-4">
                            <label for="inputState">Curency Type</label>
                            <select id="inputState" className="form-control">
                                <option selected disabled>Choose...</option>
                                <option>₹ - INR</option>
                                <option>$ - USD</option>
                            </select>
                            </div>
                            <div className="form-group col-md-2">
                            <label for="inputZip">Overdraft</label>
                            <select id="inputState" className="form-control">
                                <option selected disabled>Choose...</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                            </div>

                        </div>                        
                        <div className="form-row">
                            <div className="col-md-8">
                                <label for="transfer">Transfer Type</label>
                                <select id="transfer" className="form-control">
                                    <option selected disabled>Choose...</option>
                                    <option>Customer Transfer</option>
                                    <option>Own Transfer</option>
                                    <option>Bank Transfer For Own</option>
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label for="balence">Clear Balance</label>
                                <input type="text" className="form-control" id="balence" placeholder="************"/>
                            </div>
                        </div>
                        <button type="button" className="btn btn-outline-danger mt-4" >Proceed</button>
                    </form>
                    
                </div>
            </div>
        </div>    
    )
}
export default Home