import React,{useState} from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import home from './images/homepage.png'
import logoImg from './images/logo.png'
import logoImg2 from './images/content.jpg'
import './Home.css'
// function Home(){
    function Home(){



        /* Customer Details*/
        const [sender_id, setSender_id]= useState(" ");
        const [sender,setSender]=useState([ ]);
        const [error_id,setError_id]=useState(" ");
        
        
        
        const onSenderId = async (e)=>{
        const sender_id=e.target.value;
        if(sender_id!="")
        {
        setSender_id(sender_id);
        await (axios.get("http://localhost:8083/sender/"+sender_id))
        .then((response) => {
        setSender(response.data);
        setAmount("");
        setTransfer_fee("");
        setUpdated_clear("");
        setError_id("");
        })
        .catch((error) => {
        Object.keys(sender).forEach(function(index) {
        sender[index] = " ";
        });
        if(sender_id=="")
        setError_id("Please enter Account id");
        else
        setError_id("Account ID not Found. Please enter valid ID");
        setAmount("");
        setTransfer_fee("");
        setUpdated_clear("");
        } );
        }
        else
        {
        window.alert("Enter valid Sender ID");
        setSender_id("");
        
        
        
        }
        }
        //button proceed 
                const onchange =() => {
            window.alert("Transaction Succesful");
            }

/*Amount */
const [amount, setAmount] = useState("");
const [transfer_fee,setTransfer_fee]= useState("");
const [updated_clear,setUpdated_clear]=useState(sender.clear_balance);
const [error_amount, setError_amount]=useState(""); 
const onAmount=async (e)=>{
const amount=e.target.value;
if(amount>0){
setAmount(amount);
setTransfer_fee(amount*0.025);
if(sender.overdraft==="yes"){
setUpdated_clear(sender.clear_balance-amount-amount*0.025);
setError_amount("");
}
else{
if(sender.clear_balance >= (amount*1.25)){
setUpdated_clear(sender.clear_balance-amount*1.25);
setError_amount("");
}
else{
setUpdated_clear("");
// setError_amount("Insufficient Balance. Transfer cann't be initated");
}
}
}
else{
setAmount("");
setTransfer_fee("");
setUpdated_clear("");
window.alert("Amount cannot be negative or zero");
}
}


/* Bank Details Auto Pop up*/
const [bic, setBic] = useState("");
const [bank,setBank]= useState([]);
const [error_bank, setError_bank]=useState("");
const onBIC=async (e)=>{
const bic=e.target.value;
setBic(bic);
await (axios.get("http://localhost:8083/api/v1/bank/" +bic))
.then((response)=>{
setBank(response.data);
setError_bank("");
}
).catch((error)=>{
Object.keys(bank).forEach(function(index) {
bank[index] = " ";
});
if(bic==="")
setError_bank("Please enter BIC");
else
setError_bank("BIC not found. Please enter valid BIC");
});
}


    return(
        <div className = 'mainBg'>   
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"/>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>

            <nav className="navbar navbar-expand-lg navbar-light sticky-top" >
                <p className="navbar-brand" Link to="#"></p>
                <img src={logoImg} width="50px" height="30px" className="d-inline-block align-top" alt="Bank Logo" />
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarText">
                    <ul className="navbar-nav mr-auto"> </ul>
                    <span className="navbar-text">
                        <ul className="navbar-nav mr-auto">
                            <li className= "nav-item active">
                                <p className="nav-link" Link to="#" >Home</p>
                                <span className="sr-only">(current)</span>
                            </li>
                            <li className="nav-item">
                                <p className="nav-link" Link to="#" >Service</p>
                            </li>
                            <li className="nav-item">
                                <p className="nav-link" Link to="#" >Request</p>
                            </li>
                        </ul>
                    </span>
                </div>
            </nav>

            <div className="row m-5 pr-2 d-flex" >
                <div className="col-lg-6">
                    <div className="card1 pb-5">
                        <div className="px-3  mt-4 mb-5 border-line"> <img src={home} width='468px' height='368px'/> </div>
                    </div>
                </div>

                <div className="col-lg-6 ">

                    <form>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                            <label for="inputEmail4">Customer Id</label>
                            <input type="text" className="form-control"
                             id="inputEmail4" placeholder="***********" value={sender_id}
                             onChange = {onSenderId}
                             required/>
                              <div> {error_id}</div>  

                            </div>
                            <div className="form-group col-md-6">
                            <label for="inputPassword4">Account Holders Name</label>
                            <input type="text" className="form-control" id="inputPassword4"
                            value={sender.name} placeholder="Ravi Teja"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <label for="inputAddress">Bank Name</label>
                            <input type="text" className="form-control" id="inputAddress" value={bank.bank_name} placeholder="DBS Bank"/>
                        </div>
                        <div className="form-group">
                            <label for="inputAddress2">Mesage</label>
                            <select id="inputAddress2" className="form-control">
                                <option selected disabled>Choose...</option>
                                <option>CHQB-beneficiary customer must be paid by cheque only</option>
                                <option>CORT-Payment is made in settlement for a trader</option>
                                <option>HOLD-Beneficiary customer or claimant will call upon identification</option>
                                <option>INTC-Payment between two companies that belongs to the same group</option>
                                <option>PHOB-Please advise the intermediary institution by phone</option>
                                <option>PHOI-Please advise the intermediary by phone</option>
                                <option>PHON-Please advise the account with institution by phone</option>
                                <option>REPA-Payments has a related e-Payments reference</option>
                                <option>SDVA-Payment must be executed with same day</option>
                            </select>
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                            <label for="inputCity">BIC CODE</label>
                            <input type="text" className="form-control" id="inputCity" value ={bic}
                                onChange={onBIC}  required placeholder="************"/>
                            </div>
                            <div className="form-group col-md-4">
                            <label for="inputState">Curency Type</label>
                            <select id="inputState" className="form-control">
                                <option selected disabled>Choose...</option>
                                <option>₹ - INR</option>
                                <option>$ - USD</option>
                            </select>
                            </div>
                            <div className="form-group col-md-2">
                            <label for="inputZip">Overdraft</label>
                            <select id="inputState" className="form-control">
                                <option selected disabled>Choose...</option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                            </div>

                        </div>                        
                        <div className="form-row">
                            <div className="col-md-8">
                                <label for="transfer">Transfer Type</label>
                                <select id="transfer" className="form-control">
                                    <option selected disabled>Choose...</option>
                                    <option>Customer Transfer</option>
                                    <option>Own Transfer</option>
                                    <option>Bank Transfer For Own</option>
                                </select>
                            </div>
                            <div className="col-md-4">
                                <label for="balence">Clear Balance</label>
                                <input type="text"   className="form-control" id="balence" value={sender.clear_balance} placeholder="************"/>
                            </div>
                            <div className="col-md-4"><br/>
                                <label for="balence">Enter Amount</label>
                                <input type="text" className="form-control" id="balence" onChange={onAmount} value={amount} placeholder="************"/>
                                <div>{error_amount}</div>
                            </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <div className="col-md-4"><br/>
                                <label for="balence">Transfer Fee</label>
                                <input type="text" className="form-control" id="balence" value={transfer_fee} placeholder="************"/>
                            </div>
                            </div>
                          
                        <button type="button" onClick={onchange} className="btn btn-outline-danger mt-4" >Proceed</button>
                    </form>
                    
                </div>
            </div>
        </div>    
    )
}
export default Home